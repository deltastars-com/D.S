import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.deltastars.store', // المعرف الفريد للتطبيق في المتاجر
  appName: 'دلتا ستارز',
  webDir: 'dist', // مجلد الإنتاج الخاص بـ Vite
  server: {
    androidScheme: 'https',
    iosScheme: 'https',
    cleartext: true // للسماح بالاتصالات الخارجية إذا لزم الأمر
  },
  plugins: {
    PushNotifications: {
      presentationOptions: ["badge", "sound", "alert"],
    },
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#064e3b", // اللون الأخضر الداكن الخاص بالمتجر
      showSpinner: false,
    },
    GoogleMaps: { 
      apiKey: "AIzaSyAwjGrOiVKGEa9EtVlgU9p9E42JCFqKIHw" 
    }
  }
};

export default config;
