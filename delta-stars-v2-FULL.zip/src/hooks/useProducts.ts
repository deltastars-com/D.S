import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export const useProducts = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      const [{ data: p }, { data: c }] = await Promise.all([
        supabase.from('products').select('*').order('id', { ascending: true }),
        supabase.from('categories').select('*').order('id', { ascending: true }),
      ]);
      setProducts(p || []);
      setCategories(c || []);
    };
    void load();
  }, []);

  return { products, categories };
};
